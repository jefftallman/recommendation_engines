# GRAND Stack Workshop

## What is GRAND stack?

**G**raphQL, **R**eact, **A**pollo, **N**eo4j **D**atabase. The GRAND stack is a combination of modern technologies for building scalable applications for the web and mobile.

## **G**raphQL

GraphQL is a query language and runtime for building APIs. Instead of defining many endpoints and the data returned by each endpoint, GraphQL uses a well-defined schema and type system to describe what data is available from the API. Using GraphQL, clients query for only the data they require.

## **R**eact

React is a JavaScript library for building user interfaces. React is declarative and component-based, allowing for encapsulating UI logic in components that can be reused, composed, and combined to build powerful user interfaces.

## **A**pollo

Apollo is a suite of open source tools for working with GraphQL. Apollo Client is a flexible, production ready GraphQL client for React and native apps.

## **N**eo4j **D**atabase

Neo4j is a scalable native graph database that allows for flexible intuitive data modeling and fast near real time querying using Cypher, the query language for graphs.

## Overview

api is the apollo and graphql 
ui is react front end
npm start for both

