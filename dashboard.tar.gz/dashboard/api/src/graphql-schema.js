import GraphQLJSON from "graphql-type-json";
import {
  executeInParallel,
  getHeadcountsQueries,
  getPersonnelQuery,
  formatHeadcountResults,
  formatPersonnelResults
} from "./queryUtil";

export const typeDefs = `
  scalar JSON
      
  type Query {
    getHeadcountOverTime(dimensions: [String], filters: [JSON], year: Int, filled: String): JSON
    getPersonnel(dimensions: [String], filters: [JSON], year: Int, filled: String): JSON
    getPersonnelDetails(ids: [ID]): JSON
    orgLevel1s: [String]
    orgLevel2s: [String]
    orgLevel3s: [String]
    divisions: [String]
    subDivisions: [String]
    regions: [String]
    subsidiaries: [String]
    countries: [String]
    personnelAreas: [String]
    functions: [String]
    subFunctions: [String]
    employeeStatuses: [String]
    employeeGroups: [String]
    salaryGradeBands: [String]
    genders: [String]
    expatTypes: [String]
  }
`;

const getNames = async (driver, label) => {
  const session = driver.session();
  const result = await session.run(
    `MATCH (n:${label}) RETURN DISTINCT n.name AS name`
  );
  return result.records.map(rec => rec.get("name"));
};

export const resolvers = {
  JSON: GraphQLJSON,
  Query: {
    orgLevel1s: async (root, args, { driver }) =>
      await getNames(driver, "OrgLevel1"),
    orgLevel2s: async (root, args, { driver }) =>
      await getNames(driver, "OrgLevel2"),
    orgLevel3s: async (root, args, { driver }) =>
      await getNames(driver, "OrgLevel3"),
    divisions: async (root, args, { driver }) =>
      await getNames(driver, "Division"),
    subDivisions: async (root, args, { driver }) =>
      await getNames(driver, "SubDivision"),
    regions: async (root, args, { driver }) => await getNames(driver, "Region"),
    subsidiaries: async (root, args, { driver }) =>
      await getNames(driver, "Subsidiary"),
    countries: async (root, args, { driver }) =>
      await getNames(driver, "Country"),
    personnelAreas: async (root, args, { driver }) =>
      await getNames(driver, "PersonnelArea"),
    functions: async (root, args, { driver }) =>
      await getNames(driver, "Function"),
    subFunctions: async (root, args, { driver }) =>
      await getNames(driver, "SubFunction"),
    employeeStatuses: async (root, args, { driver }) =>
      await getNames(driver, "EmpStatus"),
    employeeGroups: async (root, args, { driver }) =>
      await getNames(driver, "EmpGroup"),
    salaryGradeBands: async (root, args, { driver }) =>
      await getNames(driver, "SalaryGradeBand"),
    genders: async (root, args, { driver }) => await getNames(driver, "Gender"),
    expatTypes: async (root, args, { driver }) =>
      await getNames(driver, "ExpatType"),
    getHeadcountOverTime: async (
      _,
      { dimensions, filters, year, filled },
      { driver }
    ) => {
      let statements = getHeadcountsQueries(
        dimensions,
        filters,
        year,
        filled
      ).map(query => {
        return { query: query, params: null };
      });

      statements.forEach(statement => {
        console.log(statement.query + "\n---\n");
      });

      const results = await executeInParallel(statements, driver);
      return formatHeadcountResults(results, dimensions);
    },
    getPersonnel: async (
      _,
      { dimensions, filters, year, filled },
      { driver }
    ) => {
      const statement = getPersonnelQuery(dimensions, filters, year, filled);
      console.log(statement + "\n---\n");
      const result = await driver.session().run(statement, null);
      return formatPersonnelResults(result, dimensions);
    },
    getPersonnelDetails: async (_, { ids }, { driver }) => {
      const statement = `
        MATCH (per:Personnel) WHERE per.id IN $ids
        MATCH (per)-[:HAS_ACTIVE_STATUS]->(posStat:PositionStatus)-[:HAS_POSITION]->(pos:Position)
        MATCH (pos)-[:WORKS_IN]->(persArea:PersonnelArea)
        MATCH (pos)-[:HAS_FUNCTION]->(func:Function)
        MATCH (pos)-[:HAS_SUBFUNCTION]->(subf:SubFunction)
        MATCH (posStat)-[:IN_EMPLOYEE_GROUP]->(empG:EmpGroup)
        RETURN 
          per.firstName AS firstName,
          per.lastName AS lastName,
          pos.description AS position,
          pos.id AS positionID,
          persArea.name AS personnelArea,
          func.name AS function,
          subf.name AS subFunction,
          empG.name AS employeeGroup
      `;
      const result = await driver.session().run(statement, { ids });
      return result.records.map(rec => ({
        firstName: rec.get("firstName"),
        lastName: rec.get("lastName"),
        positionID: rec.get("positionID"),
        position: rec.get("position"),
        personnelArea: rec.get("personnelArea"),
        function: rec.get("function"),
        subFunction: rec.get("subFunction"),
        employeeGroup: rec.get("employeeGroup")
      }));
    }
  }
};
