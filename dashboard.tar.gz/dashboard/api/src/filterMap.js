export const filterMap = {
    function: {
      label: "Function",
      property: "name",
      connectsTo: "position",
      relationship: "HAS_FUNCTION"
    },
    subfunction: {
      label: "SubFunction",
      property: "name",
      connectsTo: "position",
      relationship: "HAS_SUBFUNCTION"
    },
    division: {
      label: "Division",
      property: "name",
      connectsTo: "position",
      relationship: "IN_DIVISION"
    },
    subdivision: {
      label: "SubDivision",
      property: "name",
      connectsTo: "position",
      relationship: "IN_SUBDIVISION"
    },
    gender: {
      label: "Gender",
      property: "name",
      connectsTo: "personnel",
      relationship: "HAS_GENDER"
    },
    region: {
      label: "Region",
      property: "name",
      connectsTo: "position",
      relationship: "IN_REGION"
    },
    country: {
      label: "Country",
      property: "name",
      connectsTo: "position",
      relationship: "LOCATED_IN"
    },
    orglevel1: {
      label: "OrgLevel1",
      property: "name",
      connectsTo: "position",
      relationship: "IN_ORG_LEVEL1"
    },
    orglevel2: {
      label: "OrgLevel2",
      property: "name",
      connectsTo: "position",
      relationship: "IN_ORG_LEVEL2"
    },
    orglevel3: {
      label: "OrgLevel3",
      property: "name",
      connectsTo: "position",
      relationship: "IN_ORG_LEVEL3"
    },
    empgroup: {
      label: "EmpGroup",
      property: "name",
      connectsTo: "positionstatus",
      relationship: "IN_EMPLOYEE_GROUP"
    },
    empstatus: {
      label: "EmpStatus",
      property: "name",
      connectsTo: "positionstatus",
      relationship: "HAS_STATUS"
    },
    expattype: {
      label: "ExpatType",
      property: "name",
      connectsTo: "positionstatus",
      relationship: "HAS_EXPAT_TYPE"
    },
    personnelarea: {
      label: "PersonnelArea",
      property: "name",
      connectsTo: "position",
      relationship: "WORKS_IN"
    },
    salarygrade: {
      label: "SalaryGrade",
      property: "name",
      connectsTo: "positionstatus",
      relationship: "HAS_SALARY_GRADE"
    },
    salarygradeband: {
      label: "SalaryGradeBand",
      property: "name",
      connectsTo: "position",
      relationship: "HAS_GRADE_BAND"
    },
    subsidiary: {
      label: "Subsidiary",
      property: "name",
      connectsTo: "position",
      relationship: "HAS_SUBSIDIARY"
    },
    salariedclerical: {
      label: "SalariedClerical",
      property: "id",
      connectsTo: "positionstatus",
      relationship: "IS"
    }
  };
  
  