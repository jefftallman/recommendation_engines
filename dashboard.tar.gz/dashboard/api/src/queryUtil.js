import { filterMap } from "./filterMap.js";

export function getHeadcountsQueries(dimensions, filters, year, filled) {
  return getQueries(dimensions, filters, year, filled, "headcount");
}

export function getPersonnelQuery(dimensions, filters, year, filled) {
  return getQueries(dimensions, filters, year, filled, "personnel")[0];
}

function getQueries(dimensions, filters, startYear, filled, returnType) {
  const statements = getStatements(dimensions, filters, filled, returnType);
  const returnStatement = getReturnStatement(returnType, filled, dimensions);
  // build out a query for each year
  let years = [startYear];
  if (returnType == "headcount") {
    years = [
      startYear,
      startYear - 1,
      startYear - 2,
      startYear - 3,
      startYear - 4
    ];
  }
  return years.map(year => {
    // construct the base for the query
    let baseQuery = `MATCH (year:Year)<-[:ACTIVE_IN_${year}]-(positionstatus:PositionStatus)-[:HAS_POSITION]->(position:Position)\n`;
    if (filled == "open") {
      baseQuery += `WHERE not exists((positionstatus)<-[:HAS_HISTORY]-(:Personnel))\nWITH *\n`;
    }
    if (filled == "filled") {
      baseQuery += `MATCH (positionstatus)<-[:HAS_HISTORY]-(personnel:Personnel)\nWITH *\n`;
    } else {
      baseQuery +=
        "OPTIONAL MATCH (positionstatus)<-[:HAS_HISTORY]-(personnel:Personnel)\nWITH *\n";
    }
    // construct the final query
    return baseQuery + statements + returnStatement;
  });
}

// parses dimensions and filters and builds the necessary statements
function getStatements(dimensions, filters, filled, returnType) {
  let statements = {};
  // parse filters
  filters.forEach(filter => {
    const { label, property, connectsTo, relationship } = filterMap[
      filter.filter
    ];
    // check that the filter is valid
    if (connectsTo == "personnel" && filled != "filled") {
      throw `Can only use ${label} as a filter when looking at filled positions`;
    }
    statements[filter.filter] =
      `MATCH (${connectsTo})-[:${relationship}]-(${label.toLowerCase()}:${label})\n` +
      `WHERE ${label.toLowerCase()}.${property} IN [${filter.values
        .map(i => {
          return `"${i}"`;
        })
        .join(", ")}]`;
  });
  // parse dimensions
  dimensions.forEach(dimension => {
    const { label, property, connectsTo, relationship } = filterMap[dimension];
    // check that the dimension is valid
    if (connectsTo == "personnel" && filled != "filled") {
      throw `Can only use ${label} as a dimension when looking at filled positions`;
    }
    // create a match statement for the filter (only if one does not already exist)
    if (statements[dimension] == null) {
      statements[
        dimension
      ] = `MATCH (${connectsTo})-[:${relationship}]-(${label.toLowerCase()}:${label})`;
    }
  });
  // if return type is personnel add addtional detail matches
  if (returnType == "personnel") {
    ["function", "subfunction", "personnelarea", "empgroup"].forEach(detail => {
      const { label, property, connectsTo, relationship } = filterMap[detail];
      if (statements[detail] == null) {
        statements[
          detail
        ] = `OPTIONAL MATCH (${connectsTo})-[:${relationship}]-(${label.toLowerCase()}:${label})`;
      }
    });
  }
  // join all statements
  return Array.from(Object.values(statements)).join("\n") + "\n";
}

// builds the return statement based on the given dimensions
function getReturnStatement(returnType, filled, dimensions) {
  if (returnType == "personnel") {
    return "RETURN position, personnel, function, subfunction, personnelarea, empgroup";
  }
  let returnClauses = new Set();
  let orderByClauses = new Set();
  // parse dimensions
  dimensions.map(dimension => {
    const { label, property, connectsTo } = filterMap[dimension];
    console.log(dimension);
    // check that the dimension is valid
    if (connectsTo == "personnel" && filled != "filled") {
      throw `Can only use ${label} as a dimension when looking at filled positions`;
    }
    returnClauses.add(
      label.toLowerCase() + "." + property + " AS " + label.toLowerCase()
    );
    orderByClauses.add(label.toLowerCase());
  });
  // build out the statement
  return (
    "RETURN " +
    Array.from(returnClauses).join(", ") +
    ", year.year AS year, count(Distinct position) as headcount \nORDER BY " +
    Array.from(orderByClauses).join(", ")
  );
}

export async function executeInParallel(statements, driver) {
  const resultPromises = statements.map(statement => {
    const session = driver.session();
    return session.run(statement.query, statement.params);
  });
  const results = Promise.all(resultPromises);
  return results;
}

export function recursiveInsert(json, dimensions, record, i) {
  if (i < dimensions.length - 1 && json[record.get(dimensions[i])] != null) {
    recursiveInsert(json[record.get(dimensions[i])], dimensions, record, i + 1);
  } else if (i < dimensions.length - 1) {
    json[record.get(dimensions[i])] = {};
    recursiveInsert(json[record.get(dimensions[i])], dimensions, record, i + 1);
  } else if (json[record.get(dimensions[i])] != null) {
    let obj = {};
    obj[record.get("year")] = record.get("headcount");
    json[record.get(dimensions[i])].push(obj);
  } else {
    let headcount = {};
    headcount[record.get("year")] = record.get("headcount");
    json[record.get(dimensions[i])] = [headcount];
  }
}

export function formatHeadcountResults(results, dimensions) {
  let json = {};
  results.forEach(result => {
    result.records.forEach(record => {
      recursiveInsert(json, dimensions, record, 0);
    });
  });
  return json;
}

export function formatPersonnelResults(result, dimensions) {
  return result.records.map(record => {
    const firstName =
      record.get("personnel") == null
        ? "null"
        : record.get("personnel").properties.firstName;
    const lastName =
      record.get("personnel") == null
        ? "null"
        : record.get("personnel").properties.lastName;
    const positionTitle =
      record.get("position") == null
        ? "null"
        : record.get("position").properties.description;
    const positionID =
      record.get("position") == null
        ? "null"
        : record.get("position").properties.id;
    const fn =
      record.get("function") == null
        ? "null"
        : record.get("function").properties.name;
    const subfn =
      record.get("subfunction") == null
        ? "null"
        : record.get("subfunction").properties.name;
    const personnelArea =
      record.get("personnelarea") == null
        ? "null"
        : record.get("personnelarea").properties.name;
    const employeeGroup =
      record.get("empgroup") == null
        ? "null"
        : record.get("empgroup").properties.name;
    return {
      firstName,
      lastName,
      positionTitle,
      positionID,
      personnelArea,
      function: fn,
      subFunction: subfn,
      employeeGroup
    };
  });
}
