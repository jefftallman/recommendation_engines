import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import App from "./App";
import ApolloClient from "apollo-boost";
import { BrowserRouter as Router, Route } from "react-router-dom";
import { ApolloProvider } from "react-apollo";
import PersonnelTable from "./components/PersonnelTable";
import FlightRiskScreen from "./components/FlightRiskScreen";

const client = new ApolloClient({
  uri: process.env.REACT_APP_GRAPHQL_URI
});

const Main = () => (
  <Router>
    <ApolloProvider client={client}>
      <Route exact path="/" component={App} />
      <Route path="/personnel" component={PersonnelTable} />
      <Route path="/flight-risk" component={FlightRiskScreen} />
    </ApolloProvider>
  </Router>
);

ReactDOM.render(<Main />, document.getElementById("root"));
