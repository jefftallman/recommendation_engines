import React from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import styled from "styled-components";

const StyledDatePicker = styled(DatePicker)`
  font-size: 15px;
  border-radius: 4px;
  border: 1px solid #aeaeae;
  margin-top: 4px;
  min-height: 32px;
  border-color: hsl(0, 0%, 80%);
  outline: 0;
  padding: 2px 10px;
  cursor: default;
  &:hover {
    border-color: hsl(0, 0%, 70%);
  }
  &:active {
    border-color: #2684ff;
    border-width: 2px;
  }
  &:focus {
    border-color: #2684ff;
    border-width: 2px;
  }
`;

const DatePickerContainer = styled.div`
  display: flex;
  flex-direction: column;

  label {
    font-size: 14px;
    font-weight: bold;
    margin-bottom: 2px;
  }
`;

const DateSelect = ({ selectedDate, handleDateChange }) => (
  <DatePickerContainer>
    <label>Select date</label>
    <StyledDatePicker
      selected={selectedDate}
      onChange={handleDateChange}
      todayButton={"Today"}
    />
  </DatePickerContainer>
);

export default DateSelect;
