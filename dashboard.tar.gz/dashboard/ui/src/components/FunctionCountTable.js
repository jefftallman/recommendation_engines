import React from "react";
import { Query } from "react-apollo";
import gql from "graphql-tag";
import ReactTable from "react-table";
import "react-table/react-table.css";
import styled from "styled-components";
import "./table.css";

const HEADCOUNT_QUERY = gql`
  query HeadcountQuery($year: Int) {
    headcountOverTime(year: $year)
  }
`;

const StyledTable = styled(ReactTable)`
  margin-top: 15px;
`;

const FunctionCountTable = ({ selectedDate, handleFunctionSelect }) => {
  const dateFormat = "M/D/YYYY";
  const year = selectedDate.get("year");
  return (
    <Query query={HEADCOUNT_QUERY} variables={{ year }}>
      {({ loading, error, data, refetch }) => {
        if (loading) return null;
        if (error) {
          console.error(error);
          return null;
        }
        // this is not a good way to do this...
        let tableData = data.headcountOverTime.map(row => ({
          functionName: row.functionName,
          year1Count: row.year1Count,
          year2Count: row.year2Count,
          year3Count: row.year3Count,
          year4Count: row.year4Count,
          year5Count: row.year5Count
        }));
        let year1Count = 0;
        let year2Count = 0;
        let year3Count = 0;
        let year4Count = 0;
        let year5Count = 0;
        tableData.forEach(function(row) {
          year1Count += row.year1Count;
          year2Count += row.year2Count;
          year3Count += row.year3Count;
          year4Count += row.year4Count;
          year5Count += row.year5Count;
        });
        const totalsRow = {
          functionName: "Total",
          year1Count,
          year2Count,
          year3Count,
          year4Count,
          year5Count
        };
        tableData.push(totalsRow);
        return (
          <StyledTable
            defaultPageSize={tableData.length}
            className="-highlight -striped hoverable"
            style={{ textAlign: "center" }}
            showPagination={false}
            columns={[
              {
                Header: "Function",
                accessor: "functionName",
                getProps: (state, rowInfo) => {
                  return {
                    style: {
                      textAlign: "left"
                    }
                  };
                }
              },
              {
                Header: `12/31/${year - 4}`,
                accessor: "year5Count"
              },
              {
                Header: `12/31/${year - 3}`,
                accessor: "year4Count"
              },
              {
                Header: `12/31/${year - 2}`,
                accessor: "year3Count"
              },
              {
                Header: `12/31/${year - 1}`,
                accessor: "year2Count"
              },
              {
                Header: selectedDate.format(dateFormat),
                accessor: "year1Count"
              }
            ]}
            data={tableData}
            getTdProps={(state, rowInfo) => {
              return {
                onClick: e => {
                  if (rowInfo.original.functionName !== "Total") {
                    handleFunctionSelect(rowInfo.original.functionName);
                  }
                }
              };
            }}
          />
        );
      }}
    </Query>
  );
};

export default FunctionCountTable;
