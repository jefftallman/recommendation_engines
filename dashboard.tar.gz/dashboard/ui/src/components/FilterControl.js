import React from "react";
import styled from "styled-components";
import Select from "react-select";
import { Query } from "react-apollo";
import gql from "graphql-tag";

const SelectContainer = styled.div`
  display: flex;
`;

const Column = styled.div`
  padding: 10px;
`;

const StyledSelect = styled(Select)`
  width: 220px;
  margin-top: 4px;
`;

const SelectLabelContainer = styled.div`
  margin-bottom: 16px;

  label {
    font-size: 14px;
    font-weight: bold;
  }
`;

const SelectWithLabel = ({ label, options, value, onChange }) => (
  <SelectLabelContainer>
    <label>{label}</label>
    <StyledSelect
      options={options}
      placeholder="(All)"
      isMulti={true}
      isClearable={true}
      closeMenuOnSelect={false}
      value={value}
      onChange={onChange}
    />
  </SelectLabelContainer>
);

const FilterDropdown = ({ queryName, label, value, onChange }) => (
  <Query query={gql(`{names: ${queryName}}`)}>
    {({ loading, error, data }) => {
      const options =
        loading || error ? [] : data.names.map(n => ({ value: n, label: n }));
      const placeholder = loading ? "Loading..." : error ? "Error" : "(All)";
      if (error) console.error(error);
      return (
        <SelectLabelContainer>
          <label>{label}</label>
          <StyledSelect
            options={options}
            placeholder={placeholder}
            isMulti={true}
            isClearable={true}
            closeMenuOnSelect={false}
            value={value}
            onChange={onChange}
          />
        </SelectLabelContainer>
      );
    }}
  </Query>
);

const FilterControl = ({ filterValues, handleFilterChange }) => {
  return (
    <SelectContainer>
      <Column>
        <FilterDropdown
          queryName="orgLevel1s"
          label="Org Level 1"
          value={filterValues.orgLevel1}
          onChange={e => handleFilterChange("orgLevel1", e)}
        />
        <FilterDropdown
          queryName="orgLevel2s"
          label="Org Level 2"
          value={filterValues.orgLevel2}
          onChange={e => handleFilterChange("orgLevel2", e)}
        />
        <FilterDropdown
          queryName="orgLevel3s"
          label="Org Level 3"
          value={filterValues.orgLevel3}
          onChange={e => handleFilterChange("orgLevel3", e)}
        />
        <FilterDropdown
          queryName="divisions"
          label="Division"
          value={filterValues.division}
          onChange={e => handleFilterChange("division", e)}
        />
        <FilterDropdown
          queryName="subDivisions"
          label="Sub Division"
          value={filterValues.subDivision}
          onChange={e => handleFilterChange("subDivision", e)}
        />
        <FilterDropdown
          queryName="regions"
          label="Region"
          value={filterValues.region}
          onChange={e => handleFilterChange("region", e)}
        />
        <FilterDropdown
          queryName="subsidiaries"
          label="Subsidiary"
          value={filterValues.subsidiary}
          onChange={e => handleFilterChange("subsidiary", e)}
        />
        <FilterDropdown
          queryName="countries"
          label="Country"
          value={filterValues.country}
          onChange={e => handleFilterChange("country", e)}
        />
        <FilterDropdown
          queryName="personnelAreas"
          label="Personnel Area"
          value={filterValues.personnelArea}
          onChange={e => handleFilterChange("personnelArea", e)}
        />
      </Column>
      <Column>
        <FilterDropdown
          queryName="functions"
          label="Function"
          value={filterValues.functionName}
          onChange={e => handleFilterChange("functionName", e)}
        />
        <FilterDropdown
          queryName="subFunctions"
          label="Sub Function"
          value={filterValues.subFunction}
          onChange={e => handleFilterChange("subFunction", e)}
        />
        <FilterDropdown
          queryName="employeeStatuses"
          label="Employee Status"
          value={filterValues.empStatus}
          onChange={e => handleFilterChange("empStatus", e)}
        />
        <FilterDropdown
          queryName="employeeGroups"
          label="Employee Group"
          value={filterValues.empGroup}
          onChange={e => handleFilterChange("empGroup", e)}
        />
        <SelectWithLabel
          label="Salaried Clerical"
          options={[
            { value: "true", label: "Yes" },
            { value: "false", label: "No" }
          ]}
          value={filterValues.salariedClerical}
          onChange={e => handleFilterChange("salariedClerical", e)}
        />
        <FilterDropdown
          queryName="salaryGradeBands"
          label="Salary Grade Band"
          value={filterValues.salaryGradeBand}
          onChange={e => handleFilterChange("salaryGradeBand", e)}
        />
        <FilterDropdown
          queryName="genders"
          label="Gender"
          value={filterValues.gender}
          onChange={e => handleFilterChange("gender", e)}
        />
        <FilterDropdown
          queryName="expatTypes"
          label="Expat Type"
          value={filterValues.expatType}
          onChange={e => handleFilterChange("expatType", e)}
        />
      </Column>
    </SelectContainer>
  );
};

export default FilterControl;
