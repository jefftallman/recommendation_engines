import React from "react";
import ReactTable from "react-table";
import "react-table/react-table.css";
import styled from "styled-components";
import { Query } from "react-apollo";
import gql from "graphql-tag";
import QueryString from "query-string";

const GET_HEADCOUNT = gql`
  query Headcount(
    $year: Int
    $dimensions: [String]
    $filters: [JSON]
    $filled: String
  ) {
    headcountData: getHeadcountOverTime(
      year: $year
      dimensions: $dimensions
      filters: $filters
      filled: $filled
    )
  }
`;

const ClickableCell = styled.div`
  &:hover {
    cursor: pointer;
    font-weight: bold;
  }
  height: 100%;
  width: 100%;
  text-align: center;
`;

const TableHeader = styled.span`
  font-weight: bold;
`;

const createColumns = (dimensions, selectedDate) => {
  const columns = [];
  dimensions.forEach(dimension => {
    columns.push({
      Header: props => <TableHeader>{dimension.label}</TableHeader>,
      accessor: dimension.value,
      getProps: (state, rowInfo) => ({ style: { textAlign: "left" } })
    });
  });
  const year = selectedDate.get("year");
  for (let i = year - 4; i < year; i++) {
    columns.push({
      Header: props => <TableHeader>{`12/31/${i}`}</TableHeader>,
      accessor: `${i}`,
      Cell: props => <ClickableCell>{props.value}</ClickableCell>,
      year: i
    });
  }
  columns.push({
    Header: props => (
      <TableHeader>{selectedDate.format("MM/DD/YYYY")}</TableHeader>
    ),
    accessor: `${year}`,
    Cell: props => <ClickableCell>{props.value}</ClickableCell>,
    year
  });
  return columns;
};

// This is a really terrible and difficult to maintain way to do this
const formatDataForTable = (dimensions, headcountData) => {
  const data = [];
  if (dimensions.length === 1) {
    const firstDimensions = Object.keys(headcountData);
    firstDimensions.forEach(firstDimension => {
      const row = {
        [dimensions[0]["value"]]: firstDimension
      };
      const counts = headcountData[firstDimension];
      counts.forEach(count => {
        const [year] = Object.keys(count);
        const [yearCount] = Object.values(count);
        row[year] = yearCount;
      });
      data.push(row);
    });
  } else if (dimensions.length === 2) {
    const firstDimensions = Object.keys(headcountData);
    firstDimensions.forEach(firstDimension => {
      const secondDimensions = Object.keys(headcountData[firstDimension]);
      secondDimensions.forEach(secondDimension => {
        const row = {
          [dimensions[0]["value"]]: firstDimension,
          [dimensions[1]["value"]]: secondDimension
        };
        const counts = headcountData[firstDimension][secondDimension];
        counts.forEach(count => {
          const [year] = Object.keys(count);
          const [yearCount] = Object.values(count);
          row[year] = yearCount;
        });
        data.push(row);
      });
    });
  } else if (dimensions.length === 3) {
    const firstDimensions = Object.keys(headcountData);
    firstDimensions.forEach(firstDimension => {
      const secondDimensions = Object.keys(headcountData[firstDimension]);
      secondDimensions.forEach(secondDimension => {
        const thirdDimensions = Object.keys(
          headcountData[firstDimension][secondDimension]
        );
        thirdDimensions.forEach(thirdDimension => {
          const row = {
            [dimensions[0]["value"]]: firstDimension,
            [dimensions[1]["value"]]: secondDimension,
            [dimensions[2]["value"]]: thirdDimension
          };
          const counts =
            headcountData[firstDimension][secondDimension][thirdDimension];
          counts.forEach(count => {
            const [year] = Object.keys(count);
            const [yearCount] = Object.values(count);
            row[year] = yearCount;
          });
          data.push(row);
        });
      });
    });
  }
  return data;
};

let cachedColumns = null;
let cachedTableData = null;

const HeadcountTable = ({
  dimensions,
  positionType,
  date,
  filters,
  handleHeadcountClick
}) => {
  if (dimensions.length === 0) {
    return <div>Please select at least one dimension</div>;
  }

  const variables = {
    dimensions: dimensions.map(d => d.value.toLowerCase()),
    filled: positionType.value,
    year: date.get("year"),
    filters
  };

  return (
    <Query query={GET_HEADCOUNT} variables={variables}>
      {({ loading, error, data }) => {
        if (loading && cachedColumns !== null && cachedTableData !== null) {
          return (
            <ReactTable
              loading={true}
              style={{ textAlign: "center" }}
              columns={cachedColumns}
              data={cachedTableData}
            />
          );
        } else if (loading) {
          return null;
        }
        if (error) {
          console.log(error.message);
          return <p>{error.message}</p>;
        }

        const { headcountData } = data;
        const columns = createColumns(dimensions, date);
        const tableData = formatDataForTable(dimensions, headcountData);
        cachedColumns = columns;
        cachedTableData = tableData;
        return (
          <ReactTable
            columns={columns}
            data={tableData}
            style={{ textAlign: "center" }}
            className="-highlight -striped"
            getTdProps={(state, rowInfo, column) => {
              return {
                onClick: e => {
                  const { year } = column;
                  if (
                    rowInfo === undefined ||
                    year === undefined ||
                    rowInfo.row[year] === undefined
                  ) {
                    return;
                  }
                  const dimensionNames = dimensions.map(d => d.value);
                  let dropdownFilters = Array.from(filters).filter(
                    filter => !dimensionNames.includes(filter.filter)
                  );
                  dimensionNames.forEach(
                    dimension => (dropdownFilters[dimension] = undefined)
                  );
                  let dimensionFilters = dimensionNames.map(d => ({
                    filter: d,
                    values: [rowInfo.original[d]]
                  }));
                  const personnelFilters = dimensionFilters.concat(
                    dropdownFilters
                  );
                  const queryString = QueryString.stringify({
                    year,
                    filters: JSON.stringify(personnelFilters),
                    positionType: positionType.value
                  });
                  window.open(`/personnel/${queryString}`);
                }
              };
            }}
          />
        );
      }}
    </Query>
  );
};

export default HeadcountTable;
