import React from "react";
import { Query } from "react-apollo";
import gql from "graphql-tag";
import ReactTable from "react-table";
import "react-table/react-table.css";
import styled from "styled-components";
import QueryString from "query-string";
import Header from "./Header";
import "./table.css";

const PERSONNEL_QUERY = gql`
  query PersonnelQuery(
    $year: Int
    $dimensions: [String]
    $filters: [JSON]
    $filled: String
  ) {
    personnel: getPersonnel(
      year: $year
      dimensions: $dimensions
      filters: $filters
      filled: $filled
    )
  }
`;

const Wrapper = styled.div`
  position: absolute;
  top: 54px;
  width: 100%;
`;

const StyledTable = styled(ReactTable)`
  margin-top: 20px;
`;

const Container = styled.div`
  padding: 0px 50px;
`;

const Key = styled.span`
  font-weight: bold;
`;

const KeyValue = ({ keyString, value }) => {
  return (
    <div style={{ marginTop: "6px" }}>
      <Key>{keyString}</Key>: {value}
    </div>
  );
};

const KeyValueContainer = styled.div`
  margin-top: 20px;
`;

const filterNameMap = {
  orglevel1: "Org Level 1",
  orglevel2: "Org Level 2",
  orgLevel3: "Org Level 3",
  division: "Division",
  subdivision: "Sub Division",
  region: "Region",
  subsidiary: "Subsidiary",
  country: "Country",
  function: "Function",
  subfunction: "Sub Function",
  empstatus: "Employee Status",
  empgroup: "Employee Group",
  salariedclerical: "Salaried Clerical",
  salarygradeband: "Salary Grade Band",
  gender: "Gender",
  expattype: "Expat Type"
};

const PersonnelTable = ({ location }) => {
  // Assuming /personnel/{queryString}
  const fullQueryString = location.pathname.slice(11);
  const parsed = QueryString.parse(fullQueryString);
  parsed.filters = JSON.parse(parsed.filters);
  const { year, filters, positionType } = parsed;
  // console.log(filters);
  return (
    <Query
      query={PERSONNEL_QUERY}
      variables={{
        year,
        filters,
        filled: positionType,
        dimensions: []
      }}
    >
      {({ loading, error, data }) => {
        if (loading) return null;
        if (error) {
          console.error(error);
          return null;
        }
        const tableData = data.personnel;
        console.log(tableData);
        return (
          <React.Fragment>
            <Header title="Personnel Details" />
            <Wrapper>
              <Container>
                <KeyValueContainer>
                  <KeyValue keyString="Year" value={year} />
                  <KeyValue keyString="Position Type" value={positionType} />
                  {filters.map(filter => (
                    <KeyValue
                      keyString={filterNameMap[filter.filter]}
                      value={filter.values.join(", ")}
                      key={filter.filter}
                    />
                  ))}
                </KeyValueContainer>
                <StyledTable
                  className="-highlight -striped hoverable"
                  columns={[
                    { Header: "First Name", accessor: "firstName" },
                    { Header: "Last Name", accessor: "lastName" },
                    { Header: "Position", accessor: "positionTitle" },
                    { Header: "Personnel Area", accessor: "personnelArea" },
                    { Header: "Function", accessor: "function" },
                    { Header: "Sub Function", accessor: "subFunction" },
                    { Header: "Employee Group", accessor: "employeeGroup" }
                  ]}
                  data={tableData}
                  getTdProps={(state, rowInfo, column) => {
                    return {
                      onClick: e => {
                        const positionID = rowInfo.original.positionID;
                        window.open(
                          `${process.env.REACT_APP_BLOOM_URI}?search=360 degree view of employee ${positionID}`
                        );
                      }
                    };
                  }}
                />
              </Container>
            </Wrapper>
          </React.Fragment>
        );
      }}
    </Query>
  );
};

export default PersonnelTable;
