import React from "react";
import styled from "styled-components";
import Select from "react-select";
import DateSelect from "./DateSelect";

const SelectContainer = styled.div`
  margin-top: 40px;
  display: flex;
  flex-direction: row;
  align-items: flex-end;
`;

const StyledSelect = styled(Select)`
  width: 240px;
  margin-right: 18px;
  margin-top: 4px;
`;

const SelectLabelContainer = styled.div`
  label {
    font-size: 14px;
    font-weight: bold;
  }
`;

const Button = styled.button`
  margin-left: 18px;
  height: 38px;
  font-size: 15px;
  font-weight: bold;
  background: #3a75c1;
  &:hover {
    background: #2e6ab8;
  }
  &:active {
    background: #4f82c3;
  }
  color: white;
  border-radius: 4px;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 0 16px;
`;

const SelectWithLabel = ({
  label,
  options,
  placeholder,
  value,
  onChange,
  isClearable
}) => (
  <SelectLabelContainer>
    <label>{label}</label>
    <StyledSelect
      options={options}
      placeholder={placeholder}
      isClearable={isClearable}
      value={value}
      onChange={onChange}
    />
  </SelectLabelContainer>
);

const dimensions = [
  { value: "function", label: "Function" },
  { value: "subfunction", label: "Sub Function" },
  { value: "division", label: "Division" },
  { value: "subdivision", label: "Sub Division" },
  { value: "gender", label: "Gender" },
  { value: "region", label: "Region" },
  { value: "country", label: "Country" },
  { value: "empgroup", label: "Employee Group" },
  { value: "empstatus", label: "Employee Status" },
  { value: "personnelarea", label: "Personnel Area" },
  { value: "salarygrade", label: "Salary Grade" },
  { value: "salarygradeband", label: "Salary Grade Band" },
  { value: "subsidiary", label: "Subsidiary" }
];

const MainControl = ({
  selectedDate,
  firstDimension,
  secondDimension,
  thirdDimension,
  positionType,
  handleDateChange,
  handleDimensionSelect,
  handlePositionTypeSelect,
  handleSubmit
}) => {
  const dimensionOptions = dimensions.filter(dimension => {
    const selectedValues = [firstDimension, secondDimension, thirdDimension]
      .filter(d => d !== null)
      .map(d => d.value);
    return !selectedValues.includes(dimension.value);
  });
  return (
    <SelectContainer>
      <SelectWithLabel
        label="First Dimension"
        options={dimensionOptions}
        isSearchable={true}
        isClearable={true}
        placeholder="Select first dimension"
        value={firstDimension}
        onChange={e => handleDimensionSelect("firstDimension", e)}
      />
      <SelectWithLabel
        label="Second Dimension"
        options={dimensionOptions}
        isSearchable={true}
        isClearable={true}
        placeholder="Select second dimension"
        value={secondDimension}
        onChange={e => handleDimensionSelect("secondDimension", e)}
      />
      <SelectWithLabel
        label="Third Dimension"
        options={dimensionOptions}
        isSearchable={true}
        isClearable={true}
        placeholder="Select third dimension"
        value={thirdDimension}
        onChange={e => handleDimensionSelect("thirdDimension", e)}
      />
      <SelectWithLabel
        label="Position Type"
        options={[
          { value: "open", label: "Open" },
          { value: "filled", label: "Filled" },
          { value: "all", label: "All" }
        ]}
        value={positionType}
        isSearchable={true}
        isClearable={false}
        placeholder="Select position type"
        onChange={e => handlePositionTypeSelect(e)}
      />
      <DateSelect
        selectedDate={selectedDate}
        handleDateChange={handleDateChange}
      />
      <Button onClick={handleSubmit}>Submit</Button>
    </SelectContainer>
  );
};

export default MainControl;
