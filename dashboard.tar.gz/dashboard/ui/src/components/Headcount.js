import React from "react";
import styled from "styled-components";
import moment from "moment";
// NOTE: moment is a bit a heavy library to use for how
// limited date logic is at the moment
import FunctionCountTable from "./FunctionCountTable";
import SubFunctionCountTable from "./SubFunctionCountTable";
import PersonnelTable from "./PersonnelTable";
import DateSelect from "./DateSelect";

const Container = styled.div`
  padding: 0px 50px;
  text-align: left;
`;

export default class Headcount extends React.Component {
  state = {
    selectedDate: moment(),
    selectedFunction: null,
    selectedSubFunction: null,
    selectedPersonnelYear: null
  };

  handleDateChange = date => this.setState({ selectedDate: date });

  handleFunctionSelect = functionName =>
    this.setState({
      selectedFunction: functionName,
      selectedSubFunction: null,
      selectedPersonnelYear: null
    });

  handleSubFunctionSelect = (subFunction, year) =>
    this.setState({
      selectedSubFunction: subFunction,
      selectedPersonnelYear: year
    });

  render() {
    const {
      selectedDate,
      selectedFunction,
      selectedSubFunction,
      selectedPersonnelYear
    } = this.state;
    return (
      <Container>
        <DateSelect
          selectedDate={selectedDate}
          handleDateChange={this.handleDateChange}
        />
        <h1>Headcount by Function</h1>
        <FunctionCountTable
          selectedDate={selectedDate}
          handleFunctionSelect={this.handleFunctionSelect}
        />
        {selectedFunction === null ? null : (
          <SubFunctionCountTable
            selectedDate={selectedDate}
            selectedFunction={selectedFunction}
            handleSubFunctionSelect={this.handleSubFunctionSelect}
          />
        )}
        {selectedSubFunction === null ? null : (
          <PersonnelTable
            selectedPersonnelYear={selectedPersonnelYear}
            selectedFunction={selectedFunction}
            selectedSubFunction={selectedSubFunction}
          />
        )}
      </Container>
    );
  }
}
