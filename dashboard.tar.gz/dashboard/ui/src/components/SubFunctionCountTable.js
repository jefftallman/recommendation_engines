import React from "react";
import { Query } from "react-apollo";
import gql from "graphql-tag";
import ReactTable from "react-table";
import "react-table/react-table.css";
import styled from "styled-components";
import "./table.css";

const SUBFUNCTION_HEADCOUNT_QUERY = gql`
  query SubFunctionHeadcountQuery($year: Int, $functionName: String) {
    headcountByFunction(year: $year, functionName: $functionName)
  }
`;

const StyledTable = styled(ReactTable)`
  margin-top: 15px;
`;

const TableTitle = styled.h3`
  margin-top: 35px;
`;

const SubFunctionCountTable = ({
  selectedDate,
  selectedFunction,
  handleSubFunctionSelect
}) => {
  const year = selectedDate.get("year");
  return (
    <React.Fragment>
      <TableTitle>{`${selectedFunction} Headcount by SubFunction`}</TableTitle>
      <Query
        query={SUBFUNCTION_HEADCOUNT_QUERY}
        variables={{ year, functionName: selectedFunction }}
      >
        {({ loading, error, data, refetch }) => {
          if (loading) return null;
          if (error) {
            console.error(error);
            return null;
          }
          return (
            <StyledTable
              className="-highlight -striped hoverable"
              style={{ textAlign: "center" }}
              columns={[
                {
                  Header: "SubFunction",
                  accessor: "subfunction",
                  getProps: (state, rowInfo) => {
                    return { style: { textAlign: "left" } };
                  }
                },
                { Header: `12/31/${year - 4}`, accessor: "year5Count" },
                { Header: `12/31/${year - 3}`, accessor: "year4Count" },
                { Header: `12/31/${year - 2}`, accessor: "year3Count" },
                { Header: `12/31/${year - 1}`, accessor: "year2Count" },
                {
                  Header: selectedDate.format("M/D/YYYY"),
                  accessor: "year1Count"
                }
              ]}
              data={data.headcountByFunction}
              getTdProps={(state, rowInfo, column) => {
                return {
                  onClick: e => {
                    if (column.Header === "SubFunction") {
                      return;
                    }
                    const year = column.Header.substring(6);
                    const subFunction = rowInfo.original.subfunction;
                    handleSubFunctionSelect(subFunction, year);
                  }
                };
              }}
            />
          );
        }}
      </Query>
    </React.Fragment>
  );
};

export default SubFunctionCountTable;
