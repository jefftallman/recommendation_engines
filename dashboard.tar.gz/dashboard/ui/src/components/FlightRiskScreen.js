import React from "react";
import ReactTable from "react-table";
import axios from "axios";
import styled from "styled-components";
import Header from "./Header";
import "./table.css";

const Container = styled.div`
  position: absolute;
  top: 54px;
  width: 100%;
`;

const SuccessionContainer = styled.div`
  h2 {
    padding-left: 50px;
    padding-right: 50px;
  }
  margin-top: 50px;
`;

const StyledTable = styled(ReactTable)`
  margin-top: 20px;
  margin-right: 50px;
  margin-left: 50px;
`;

class FlightRiskScreen extends React.Component {
  state = {
    personnelDetails: [],
    successionPosition: null,
    successionPersonnel: []
  };

  async componentDidMount() {
    const recommendationRes = await axios.post(
      process.env.REACT_APP_RECOMMENDATION_URI,
      {
        query: `
        query {
          recommendations(
            engineID: "10593b11-8177-47c6-a83a-1d9cae1b8658"
          ) {
            item
            score
          }
        }
      `
      }
    );
    const ids = recommendationRes.data.data.recommendations.map(
      rec => rec.item.id
    );
    const detailsRes = await axios.post(process.env.REACT_APP_GRAPHQL_URI, {
      query: `
        query PersonnelDetails($ids: [ID]) {
          personnelDetails: getPersonnelDetails(ids: $ids)
        }
      `,
      variables: {
        ids
      }
    });
    this.setState({ personnel: detailsRes.data.data.personnelDetails });
  }

  render() {
    return (
      <React.Fragment>
        <Header title="Top Flight Risk Personnel" />
        <Container>
          <StyledTable
            className="-highlight -striped hoverable"
            columns={[
              { Header: "First Name", accessor: "firstName" },
              { Header: "Last Name", accessor: "lastName" },
              { Header: "Position", accessor: "position" },
              { Header: "Personnel Area", accessor: "personnelArea" },
              { Header: "Function", accessor: "function" },
              { Header: "Sub Function", accessor: "subFunction" },
              { Header: "Employee Group", accessor: "employeeGroup" }
            ]}
            data={this.state.personnel}
            getTdProps={(state, rowInfo, column) => {
              return {
                onClick: async e => {
                  const positionID = rowInfo.original.positionID;
                  const positionName = rowInfo.original.position;
                  const res1 = await axios.post(
                    process.env.REACT_APP_RECOMMENDATION_URI,
                    {
                      query: `
                        query {
                          recommendations(
                            engineID: "b26f6900-ee61-444b-b34e-3261f07948f1"
                            context: {positionID: "${positionID}"}
                          ) {
                            item
                            score
                          }
                        }
                      `
                    }
                  );
                  const ids = res1.data.data.recommendations.map(
                    rec => rec.item.id
                  );
                  const detailsRes = await axios.post(
                    process.env.REACT_APP_GRAPHQL_URI,
                    {
                      query: `
                      query PersonnelDetails($ids: [ID]) {
                        personnelDetails: getPersonnelDetails(ids: $ids)
                      }
                    `,
                      variables: {
                        ids
                      }
                    }
                  );
                  console.log(detailsRes);
                  this.setState({
                    successionPosition: positionName,
                    successionPersonnel: detailsRes.data.data.personnelDetails
                  });
                }
              };
            }}
          />
          {this.state.successionPosition === null ? null : (
            <SuccessionContainer>
              <h2>
                Succession planning for {`"${this.state.successionPosition}"`}
              </h2>
              <StyledTable
                className="-highlight -striped"
                columns={[
                  { Header: "First Name", accessor: "firstName" },
                  { Header: "Last Name", accessor: "lastName" },
                  { Header: "Position", accessor: "position" },
                  { Header: "Personnel Area", accessor: "personnelArea" },
                  { Header: "Function", accessor: "function" },
                  { Header: "Sub Function", accessor: "subFunction" },
                  { Header: "Employee Group", accessor: "employeeGroup" }
                ]}
                data={this.state.successionPersonnel}
              />
            </SuccessionContainer>
          )}
        </Container>
      </React.Fragment>
    );
  }
}

export default FlightRiskScreen;
