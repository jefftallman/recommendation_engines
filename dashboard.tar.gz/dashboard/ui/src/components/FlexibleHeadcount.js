import React from "react";
import styled from "styled-components";
import moment from "moment";
import MainControl from "./MainControl";
import FilterControl from "./FilterControl";
import HeadcountTable from "./HeadcountTable";

const Container = styled.div`
  padding: 0px 50px;
  text-align: left;
`;

const BottomContainer = styled.div`
  display: flex;
  margin-top: 30px;
  justify-content: space-between;
`;

const TableContainer = styled.div`
  width: 100%;
  min-width: 1000px;
`;

const FilterContainer = styled.div`
  padding: 0px 20px;
`;

export default class FlexibleHeadcount extends React.Component {
  state = {
    selectedDate: moment(),
    firstDimension: null,
    secondDimension: null,
    thirdDimension: null,
    positionType: { value: "all", label: "All" },
    filterValues: {
      orgLevel1: [],
      orgLevel2: [],
      orgLevel3: [],
      functionName: [],
      subFunction: [],
      division: [],
      subDivision: [],
      region: [],
      country: [],
      personnelArea: [],
      subsidiary: [],
      empGroup: [],
      empStatus: [],
      salaryGradeBand: [],
      salariedClerical: [],
      gender: [],
      expatType: [],
      headcountData: []
    },
    isHeadcountDisplayed: false,
    headcountTableData: {}
  };

  handleDimensionSelect = (level, dimension) =>
    this.setState({ [level]: dimension });

  handlePositionTypeSelect = positionType => this.setState({ positionType });

  handleDateChange = date => this.setState({ selectedDate: date });

  handleFilterChange = (filterName, values) => {
    this.setState(prevState => {
      const filterValues = Object.assign({}, prevState.filterValues);
      filterValues[filterName] = values;
      return { filterValues };
    });
  };

  getDimensions = dimensions => {
    return dimensions.filter(dimension => dimension !== null);
  };

  getFilters = filterValues => {
    const filters = Object.entries(filterValues)
      .filter(f => f[1].length > 0)
      .map(f => ({
        filter: f[0] === "functionName" ? "function" : f[0].toLowerCase(),
        values: f[1].map(v => v.value)
      }));
    return filters;
  };

  handleSubmit = () => {
    this.setState(prevState => {
      const {
        firstDimension,
        secondDimension,
        thirdDimension,
        filterValues,
        positionType,
        selectedDate
      } = prevState;
      const dimensions = this.getDimensions([
        firstDimension,
        secondDimension,
        thirdDimension
      ]);
      const filters = this.getFilters(filterValues);
      return {
        isHeadcountDisplayed: true,
        headcountTableData: {
          dimensions,
          filters,
          positionType,
          date: selectedDate
        }
      };
    });
  };

  render() {
    const {
      selectedDate,
      firstDimension,
      secondDimension,
      thirdDimension,
      positionType,
      filterValues,
      isHeadcountDisplayed,
      headcountTableData
    } = this.state;
    return (
      <Container>
        <MainControl
          selectedDate={selectedDate}
          firstDimension={firstDimension}
          secondDimension={secondDimension}
          thirdDimension={thirdDimension}
          positionType={positionType}
          handlePositionTypeSelect={this.handlePositionTypeSelect}
          handleDateChange={this.handleDateChange}
          handleDimensionSelect={this.handleDimensionSelect}
          handleSubmit={this.handleSubmit}
        />
        <BottomContainer>
          <TableContainer>
            {isHeadcountDisplayed && (
              <HeadcountTable
                dimensions={headcountTableData.dimensions}
                filters={headcountTableData.filters}
                date={headcountTableData.date}
                positionType={headcountTableData.positionType}
                handleHeadcountClick={this.handleHeadcountClick}
              />
            )}
          </TableContainer>
          <FilterContainer>
            <FilterControl
              filterValues={filterValues}
              handleFilterChange={this.handleFilterChange}
            />
          </FilterContainer>
        </BottomContainer>
      </Container>
    );
  }
}
