import React from "react";
import styled from "styled-components";

const Container = styled.header`
  background-color: #ed1d23;
  height: 38px;
  padding: 8px;
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  position: fixed;
  width: 100%;
  top: 0;
  z-index: 10;
`;

const Logo = styled.img`
  width: 225px;
  position: absolute;
  left: 0;
  margin-left: 15px;
`;

const CompanyName = styled.h1`
  font-size: 24px;
  position: absolute;
  margin: 0;
  left: 15px;
  top: 15px;
`;

const Title = styled.h1`
  font-size: 24px;
`;

const Header = ({ title }) => (
  <Container>
    {/* <Logo
      src={process.env.PUBLIC_URL + "/img/colgate-palmolive-logo.svg"}
      alt="logo"
    /> */}
    <CompanyName>Acme Corp</CompanyName>
    <Title>{title}</Title>
  </Container>
);

export default Header;
