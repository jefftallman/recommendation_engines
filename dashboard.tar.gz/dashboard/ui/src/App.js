import React, { Component } from "react";
import "./App.css";
import Header from "./components/Header";
import Headcount from "./components/FlexibleHeadcount";
import styled from "styled-components";

const Wrapper = styled.div`
  position: absolute;
  top: 44px;
`;

class App extends Component {
  render() {
    return (
      <div className="App">
        <Header title="Historical Headcount Trend" />
        <Wrapper>
          <Headcount />
        </Wrapper>
      </div>
    );
  }
}

export default App;
